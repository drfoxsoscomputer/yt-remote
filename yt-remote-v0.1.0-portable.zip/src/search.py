"""Busqueda en YouTube con yt-dlp.

- Detecta si un input es un link directo de YouTube.
- Busca videos por nombre y devuelve resultados con titulo, url,
  duracion y thumbnail.
"""

import re
from dataclasses import dataclass
from typing import Any

YOUTUBE_URL_RE = re.compile(
    r"(https?://)?(www\.)?(youtube\.com|youtu\.be)/(watch|shorts|live|embed)?"
)
_LINK_RE = re.compile(
    r"^(?:https?://)?(?:www\.)?(?:youtube\.com|youtu\.be)/"
)


@dataclass
class SearchResult:
    """Un resultado de busqueda de YouTube."""

    url: str
    title: str
    duration: str
    thumbnail: str
    video_id: str = ""
    duration_seconds: int = 0
    channel: str = ""


def _build_thumbnail(video_id: str) -> str:
    """Construye la URL de la miniatura a partir del ID del video.

    Con extract_flat yt-dlp no devuelve las URLs de las miniaturas,
    pero la miniatura de YouTube siempre esta disponible en esta URL
    estable a partir del video ID.
    """
    if not video_id:
        return ""
    return f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"


_VIDEO_ID_RE = re.compile(
    r"(?:youtube\.com/(?:watch\?[^#]*v=|shorts/|live/|embed/)|youtu\.be/)"
    r"([A-Za-z0-9_-]{11})"
)


def thumbnail_from_url(url: str) -> str:
    """Deriva la miniatura de YouTube desde un link directo (watch/shorts/youtu.be).

    Sirve para items sin thumbnail cargado (links directos de /play, /now);
    si no se puede extraer el ID devuelve "".
    """
    m = _VIDEO_ID_RE.search(url or "")
    if not m:
        return ""
    return _build_thumbnail(m.group(1))


def is_youtube_link(text: str) -> bool:
    """Devuelve True si el texto es un link directo de YouTube."""
    return bool(_LINK_RE.match(text.strip()))


def search(query: str, max_results: int = 5) -> list[SearchResult]:
    """Busca videos en YouTube y devuelve los resultados."""
    import yt_dlp

    ydl_opts: "dict[str, Any]" = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "extract_flat": True,
        "noplaylist": True,
    }

    results: list[SearchResult] = []
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:  # type: ignore[arg-type]
        try:
            info = ydl.extract_info(f"ytsearch{max_results}:{query}", download=False)
        except Exception:
            return results

        entries = info.get("entries") or []
        for entry in entries:
            if not entry:
                continue
            url = entry.get("url") or entry.get("webpage_url") or ""
            if not url:
                continue
            video_id = entry.get("id") or ""
            duration = entry.get("duration") or 0
            results.append(
                SearchResult(
                    url=url,
                    title=entry.get("title") or "(sin titulo)",
                    duration=_fmt_duration(duration),
                    thumbnail=_build_thumbnail(video_id),
                    video_id=video_id,
                    duration_seconds=int(duration),
                    channel=entry.get("channel") or entry.get("uploader") or "",
                )
            )
    return results


def _fmt_duration(seconds: int | float) -> str:
    seconds = int(seconds)
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def is_playlist_url(url: str) -> bool:
    """Devuelve True si el link de YouTube apunta a una playlist o mix."""
    text = url.strip()
    if "/playlist?list=" in text:
        return True
    m = re.search(r"[?&]list=([A-Za-z0-9_-]+)", text)
    if not m:
        return False
    list_id = m.group(1)
    # Un mix (radio) tiene list id tipo RD..., RDCLAK..., RDAMVM..., etc;
    # una playlist normal es un list id plano. En ambos casos hay que
    # expandir, salvo list=WL (watch later) de sesion que no aplica aqui.
    return list_id != "WL"


def expand_playlist(url: str, max_results: int = 50) -> list[SearchResult]:
    """Expande una playlist o mix de YouTube a sus tracks.

    Usa yt-dlp con extract_flat para no descargar nada: solo los metadatos
    (id, titulo, url, duracion) de cada track. Devuelve [] si falla o si la
    URL no es una playlist.
    """
    import yt_dlp

    if not is_playlist_url(url):
        return []

    ydl_opts: "dict[str, Any]" = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "extract_flat": True,
        "noplaylist": False,
    }

    tracks: list[SearchResult] = []
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:  # type: ignore[arg-type]
        try:
            info = ydl.extract_info(url, download=False)
        except Exception:
            return tracks

        entries = info.get("entries") or []
        for entry in entries:
            if not entry or len(tracks) >= max_results:
                continue
            video_url = entry.get("url") or entry.get("webpage_url") or ""
            if not video_url:
                continue
            video_id = entry.get("id") or ""
            duration = entry.get("duration") or 0
            tracks.append(
                SearchResult(
                    url=video_url,
                    title=entry.get("title") or "(sin titulo)",
                    duration=_fmt_duration(duration),
                    thumbnail=_build_thumbnail(video_id),
                    video_id=video_id,
                    duration_seconds=int(duration),
                    channel=entry.get("channel") or entry.get("uploader") or "",
                )
            )
    return tracks


def resolve_stream_url(youtube_url: str) -> tuple[str, str | None] | None:
    """Resuelve un link de YouTube a una URL de stream directo que mpv puede reproducir.

    Usa el player client 'visionos' de yt-dlp: no le aplican el bloqueo de
    "Sign in to confirm you're not a bot" (a diferencia del client web) y
    expone los formatos de alta resolucion. Con 'android' el bot quedaba
    limitado a 360p.

    La resolucion se limita a 1080p ('bestvideo[height<=1080]+bestaudio');
    si el video no tiene esa resolucion se toma la mayor que no la supere.

    Devuelve (video_url, audio_url) o (url, None) si es un stream combinado.
    Devuelve None si no se pudo resolver.
    """
    import yt_dlp

    opts: "dict[str, Any]" = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "format": "bestvideo[height<=1080]+bestaudio/best",
        "extractor_args": {"youtube": {"player_client": ["visionos"]}},
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(youtube_url, download=False)
            if not info:
                return None

            # Stream directo (un solo URL con audio+video)
            if info.get("url"):
                return (str(info["url"]), None)

            # Streams separados (DASH: video + audio)
            requested = info.get("requested_formats")
            if requested and isinstance(requested, list):
                video_url = None
                audio_url = None
                for fmt in requested:
                    vcodec = fmt.get("vcodec", "none")
                    acodec = fmt.get("acodec", "none")
                    furl = fmt.get("url")
                    if not furl:
                        continue
                    if vcodec != "none" and not video_url:
                        video_url = str(furl)
                    elif acodec != "none" and not audio_url:
                        audio_url = str(furl)
                if video_url:
                    return (video_url, audio_url)

            # Fallback: webpage URL (mpv intentara resolver con su ytdl hook)
            if info.get("webpage_url"):
                return (str(info["webpage_url"]), None)
    except Exception:
        pass
    return None
